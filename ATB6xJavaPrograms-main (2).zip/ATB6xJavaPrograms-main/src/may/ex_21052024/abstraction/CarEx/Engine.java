package src.may.ex_21052024.abstraction.CarEx;

abstract class Engine extends GearBox {
    abstract void start();
    abstract void stop();
}
