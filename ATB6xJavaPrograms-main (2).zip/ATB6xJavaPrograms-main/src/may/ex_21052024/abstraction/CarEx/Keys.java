package src.may.ex_21052024.abstraction.CarEx;

abstract class Keys {
    abstract void openCar();
}
