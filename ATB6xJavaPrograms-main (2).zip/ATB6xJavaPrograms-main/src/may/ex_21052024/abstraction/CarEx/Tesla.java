package src.may.ex_21052024.abstraction.CarEx;

public class Tesla extends Car{

    @Override
    void brakeMech() {
        System.out.println("Break");
    }
}
