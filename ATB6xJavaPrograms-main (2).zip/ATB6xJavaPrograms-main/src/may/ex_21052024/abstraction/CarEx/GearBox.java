package src.may.ex_21052024.abstraction.CarEx;

abstract class GearBox extends Keys{
    abstract void partGearBox();
}
