package src.may.ex_21052024.abstraction.CarEx;

public class Lab197 {
    public static void main(String[] args) {
        Tesla m1 = new Tesla();
        m1.openCar();
        m1.start();
        m1.partGearBox();
        m1.stop();

  }
}
