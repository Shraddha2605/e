package src.may.ex_21052024.abstraction.interfaceKeyword;

public interface Brake {
    void applyBreak();

}
