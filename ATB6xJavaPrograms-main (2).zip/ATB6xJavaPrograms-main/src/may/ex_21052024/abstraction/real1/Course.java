package src.may.ex_21052024.abstraction.real1;

interface Course {
    void atb();
}
