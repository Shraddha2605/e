package src.may.ex_21052024.abstraction.real1;

public class Prampd extends Bonus implements Course{
    @Override
    void mtb() {

    }

    @Override
    void mql() {

    }

    @Override
    public void atb() {

    }
}
