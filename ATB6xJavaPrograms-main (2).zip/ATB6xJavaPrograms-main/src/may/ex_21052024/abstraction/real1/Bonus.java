package src.may.ex_21052024.abstraction.real1;

abstract class Bonus {
    abstract void mtb();
    abstract void mql();
}
