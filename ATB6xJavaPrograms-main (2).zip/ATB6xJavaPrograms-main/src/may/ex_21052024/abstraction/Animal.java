package src.may.ex_21052024.abstraction;

public class Animal {
    public Animal() {
    }
    void m1(){
        System.out.println("m1");
    }
    // Concrete Class - Where you don't see the abstract method or class
}
