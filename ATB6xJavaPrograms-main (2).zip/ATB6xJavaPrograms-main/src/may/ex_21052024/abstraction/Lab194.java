package src.may.ex_21052024.abstraction;

public class Lab194 {
    // Abstraction
    // Hide the Implementation
    // Car -. Engine, Types, brake, GearBox,
    // Drive help us to drive.
    // Abstract is the keyword.
    // abstract can be a class or method both.


    // Showing only the essential features of an object to the user
    // and hiding the inner details to reduce complexity.

    // How This implemented?
    // Abstract
    // Interface




}
