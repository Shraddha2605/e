package src.may.ex_21052024.abstraction.LOANEx;

public class Son extends Father{
    @Override
    void loan50K() {
        System.out.println("Son is givng 50K Loan");
    }
}
