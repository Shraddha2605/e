package src.may.ex_21052024.abstraction.LOANEx;

abstract class Father {
    abstract void loan50K();
    void loan25K(){
        System.out.println("Done by Father");
    }
    Father(){}
}
