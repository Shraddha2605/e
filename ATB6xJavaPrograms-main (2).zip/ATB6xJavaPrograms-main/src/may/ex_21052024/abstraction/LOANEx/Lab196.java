package src.may.ex_21052024.abstraction.LOANEx;

public class Lab196 {
    public static void main(String[] args) {
        Son s1 = new Son();
        s1.loan50K();
    }
}
