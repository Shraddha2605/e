package src.may.ex_21052024.abstraction.REALEx;

public class TC1_CHROME extends BaseClass{
    @Override
    String openBrowser() {
        System.out.println("Starting CHROME ...");
        return "";
    }

    @Override
    String closeBrowser() {
        System.out.println("Closing CHROME ...");
        return "";
    }
}
