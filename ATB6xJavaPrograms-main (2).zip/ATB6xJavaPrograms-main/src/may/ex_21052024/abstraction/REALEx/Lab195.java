package src.may.ex_21052024.abstraction.REALEx;

public class Lab195 {
    public static void main(String[] args) {
        TC1_CHROME chrome = new TC1_CHROME();
        chrome.openBrowser();
        chrome.closeBrowser();
    }
}
