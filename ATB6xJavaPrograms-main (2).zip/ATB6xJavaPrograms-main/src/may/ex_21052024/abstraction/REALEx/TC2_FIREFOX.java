package src.may.ex_21052024.abstraction.REALEx;

public class TC2_FIREFOX extends BaseClass{

    @Override
    String openBrowser() {
        System.out.println("Starting Firefox 1");
        return "";
    }

    @Override
    String closeBrowser() {
        System.out.println("Starting Firefox 2");
        return "";
    }
}
