package src.may.ex_28052024;

import java.util.ArrayList;
import java.util.List;

public class Lab233 {
    public static void main(String[] args) {
        List<Integer> mylist = new ArrayList();
//        mylist.add("Pramod");
//        mylist.add("Anusha");
        mylist.add(123);
//        mylist.add(true);
        System.out.println(mylist);
    }
}
