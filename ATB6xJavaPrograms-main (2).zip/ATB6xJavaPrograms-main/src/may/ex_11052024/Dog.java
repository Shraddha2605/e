package src.may.ex_11052024;

public class Dog {
    // Attribute
    String name;
    String breed;
    int legs;
    String ear;


    //Behav
    void eat(){} // method
    void walk(){}
    void bark(){}

}
