package src.may.ex_11052024;

public class Lab165 {
    // Constructors
    // default, parameter, copy constructor(<1%)

    // this, super


    // OOPs -> inheritance, poly, encap, abstraction (interface, abstrac class)
    // Practical Project -> Course Website - By OOPs concept
    // OOPs applied in the LIVE programs


    // static
}
