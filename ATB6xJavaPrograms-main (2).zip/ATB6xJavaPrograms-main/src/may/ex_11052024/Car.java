package src.may.ex_11052024;

public class Car {
    // attribute, data member, instance variable, properties
    String name;
    String size;
    String tyres;
    String model;
    String color;
    String transmissoinType;



    // behav / methods/  functionaities
    void reverse(){}
    void speedTop(){}
    void musicSystem(){
    }
}
