package src.may.ex_11052024;

public class Lab163 {
    public static void main(String[] args) {
        Dog german = new Dog(); // A,b
        Dog lab = new Dog(); // a,B
        Dog pitbull = new Dog(); //A,B


    }
}
