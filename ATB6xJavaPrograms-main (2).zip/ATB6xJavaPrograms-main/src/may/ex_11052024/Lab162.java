package src.may.ex_11052024;

public class Lab162 {
    public static void main(String[] args) {
        System.out.println("Hello");
        Person amit = new Person();
        amit.name = "Amit";
        System.out.println(amit.name);
        Person pramod = new Person();
        Person kanika = null;

        System.out.println(kanika);
        // ClassName Object_ref = Object() ->( new ClassName())
        // Class -> blueprint - Attribute, Behav - Not Real ( blueprint)
        // Object -> Real Entities -> Class - A, Behv => functions



    }
}
