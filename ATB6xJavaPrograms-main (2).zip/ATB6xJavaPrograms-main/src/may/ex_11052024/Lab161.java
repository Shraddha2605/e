package src.may.ex_11052024;

public class Lab161 {
    // 3BHK, -> 3BHK
    // Father -> 1 scoty -> me
    // God -> ( functions) -> resue in future - if required.

    // Object Class
    public static void main(String[] args) {

    }
}
