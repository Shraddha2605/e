package src.may.ex_23052024;

public class Lab205 {

}

// Nested Class

class OC {
    int a = 10;

    class IC {
        void m2() {
            System.out.println("Hi, IC" + a);
        }
    }
}
