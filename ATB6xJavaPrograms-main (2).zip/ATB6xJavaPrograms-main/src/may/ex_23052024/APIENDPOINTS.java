package src.may.ex_23052024;

public enum APIENDPOINTS {

}
