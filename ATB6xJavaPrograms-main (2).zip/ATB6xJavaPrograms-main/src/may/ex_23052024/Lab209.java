package src.may.ex_23052024;

public class Lab209 {
    public static void main(String[] args) {
        System.out.println("p1 -> "+ PRIORITYBUG.HIGH);
    }
}
