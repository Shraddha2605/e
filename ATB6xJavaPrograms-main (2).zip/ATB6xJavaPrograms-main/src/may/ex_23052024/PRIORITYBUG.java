package src.may.ex_23052024;

public enum PRIORITYBUG {
    LOW,
    MEDIUM,
    HIGH
}


