package src.may.ex_23052024;

public class Lab203 {
    public static void main(String[] args) {
        // Static -> variable, block or method
        // Static variables, method  can be accessed by ClassName
        // They belong to class.
        // They are loaded when class is loaded( CL)
        // Static block is executed 1 time, when class is loaded.


    }
}
