package src.may.ex_25052024;

public class Lab228 {
    public static void main(String[] args) {
        String sh = args[0];
        int x = Integer.parseInt(sh);
        int a = 10 / x;
    }
}
