package src.may.ex_25052024;

public class Lab229 {
    public static void main(String[] args) {
        String s1  = null;
        if (s1 != null) {
            s1.trim();
        }
        // fix this


    }
}
