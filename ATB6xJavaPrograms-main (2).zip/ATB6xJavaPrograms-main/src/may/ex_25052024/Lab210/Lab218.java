package src.may.ex_25052024.Lab210;

public class Lab218 {
    public static void main(String[] args) {
        // Exceptions
//        String s1 = null;
//        s1.trim();

        int a = 10;
        int c  = a/0;
        System.out.println(c);
    }
}
