package src.may.ex_25052024.Lab210;

public class Lab216 {
    public static void main(String[] args) {
//        APIENDPOINTS e = APIENDPOINTS.LOGIN;
//        switch (e){
//            case LOGIN -> System.out.println("Login Page code should be executed");
//            case DASHBOARD -> System.out.println("Dashboard Page code should be executed");
//        }
    }
}


