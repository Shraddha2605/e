package src.may.ex_25052024.Lab210;

public class Lab213 {
    public static void main(String[] args) {

        double d = 90.87;
        // Primtive to Wrapper - valueOf
        String s1 = String.valueOf(d);
        Double d1 = Double.valueOf(d);
        Integer i1 = Integer.valueOf((int) d);

        int r = 34; // new int();

        // Primitive Variables - Why Java is NOt 100% OOPs?
        // Wrapper class - Java 100% OOPs



    }
}
