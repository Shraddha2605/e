package src.may.ex_25052024.Lab210;

public class Lab210 {
    public static void main(String[] args) {



        // Wrapper Class - Toffy / Candy
        int a = 10;

        // int, short, byte, char, boolean, long, double float

        // Java - Class and Objects -
        // Collection Farmework - You can't the primitve data types

        // Primitve to Objects
        // We want to some extra functionalties in the Pirmite

        Integer b = 10;

        //        Primitive -> Wrapper
//        Wrapper -> Primitive




    }

}
