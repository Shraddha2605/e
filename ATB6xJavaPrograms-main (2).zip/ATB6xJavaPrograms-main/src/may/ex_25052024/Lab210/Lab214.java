package src.may.ex_25052024.Lab210;

import java.sql.Ref;

public class Lab214 {
    public static void main(String[] args) {

        int x = 400, y = 400;
        if (x == y)
            System.out.println("Same");
        else
            System.out.println("Not Same");

        // == ->Ref
                //.equals -> value in case of ? String
              // .equals -> int or ohter - Ref




    }
}
