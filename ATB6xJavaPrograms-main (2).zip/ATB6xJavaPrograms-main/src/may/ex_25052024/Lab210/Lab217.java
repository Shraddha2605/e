package src.may.ex_25052024.Lab210;

public class Lab217 {
    public static void main(String[] args) {
        // Only Test Realted to Login
        PAGES ref = PAGES.LOGIN;
        // driver.get(ref.getUrl());
        System.out.println(ref.getPage());
        System.out.println(ref.getUrl());
    }


}
