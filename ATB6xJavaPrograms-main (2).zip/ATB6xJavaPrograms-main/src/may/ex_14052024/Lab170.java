package src.may.ex_14052024;

public class Lab170 {
    public static void main(String[] args) {
        ATBPerson amitRef = new ATBPerson();
        System.out.println(amitRef.name);
        ATBPerson swapnilRef = new ATBPerson();
        // Called - 2
        // Created  - 1 -> new ATB( CL)
//        ATBPerson pramodRef = new ATBPerson("pramod",9876543210l);
//        System.out.println(pramodRef.name);
//        System.out.println(pramodRef.phone);
//
//        ATBPerson ratulRef = new ATBPerson("Ratul",1234567890l);
//        System.out.println(ratulRef.name);
//        System.out.println(ratulRef.phone);


    }
}
