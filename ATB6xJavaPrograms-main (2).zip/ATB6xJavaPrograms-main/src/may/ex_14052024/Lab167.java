package src.may.ex_14052024;

public class Lab167 {
    public static void main(String[] args) {
        ATBPerson atbPerson1 = new ATBPerson();
        // ClassName objectRef =  new keyword + ClassName();
        // Object -> new keyword + className();
        // Object Ref -> objectRef
        // ATBPerson atbPerson1 = ATBPerson(); (calling of function)

        atbPerson1.name = "Amit";
        System.out.println(atbPerson1.name);


    }
}
