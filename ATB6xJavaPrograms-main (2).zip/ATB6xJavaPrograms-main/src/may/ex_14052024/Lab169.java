package src.may.ex_14052024;

public class Lab169 {
    public static void main(String[] args) {
        ATBPerson amitRef = new ATBPerson();
        // objRef1.name = "Amit";
        System.out.println(amitRef.courseName);
        System.out.println(amitRef.isMarried);
        System.out.println(amitRef.name);
        // DC are created to assign the value of Instance variable of the class.

        // DC -> Problem -> I can't assing my values to the Instance


        ATBPerson swapnilRef = new ATBPerson();
        System.out.println(swapnilRef.name);
        System.out.println(swapnilRef.courseName);


    }
}
