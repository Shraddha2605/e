package src.may.ex_14052024;

public class Lab166 {
    // OOPs - Object-Oriented Programming
    // Class -> Blueprint to Create Object
    // Class -> Attribute(data variables) and Behaviour(data members / methods)
    // Method -> function present in the class
    // Object -> Instance of the class, Real entity, runtime entity




    // Constructors
    // default, parameter, copy constructor(<1%)

    // this, super() - keywords

    // OOPs -> inheritance, poly, Encap, abstraction (interface, abstrac class)

    // Practical Project -> Course Website - By OOPs concept
    // OOPs applied in the LIVE programs


    // Static keyword & Static Methods
}
