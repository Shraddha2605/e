package src.may.ex_14052024;

public class Lab173 {

    // DC - 30-50%
    // PC - 50-70%
    // Copy Constructor - < 1%

}
