package src.may.ex_14052024;

public class Lab168 {

    int age2 = 45; // Instance Variable
    public static void main(String[] args) {
        int age = 10; // Local Variable


    }
}
