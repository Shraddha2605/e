package src.may.ex_04052024;

public class Lab145 {
    public static void main(String[] args) {
        String name = "Pramod";




    }
}
