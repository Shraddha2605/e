package src.may.ex_30052024;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Lab241 {
    public static void main(String[] args) {
//        List stringList = null;
//        stringList.add("ATB");

        List<Integer> myMakrs = new ArrayList<>();
        myMakrs.add(91);
        myMakrs.add(87);
        myMakrs.add(80);
        Collections.sort(myMakrs);
        System.out.println(myMakrs);






    }
}
