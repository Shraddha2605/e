package src.may.ex_01052024;

public class Lab131 {
    public static void main(String[] args) {
        System.out.println(args[0]);
        System.out.println(args[1]);
        // Function - Just after this function
        // Math.pow() - pre built utilities
        // Pizza -> Base of pizza?  base + veg + cheese - Pizza




    }
}
