package src.may.ex_01052024;

public class Lab126 {
    public static void main(String[] args) {
        final int [] ages = new int[4];
        // ages = [0,0,0,0]
        ages[3] = 78;
        ages[3] = 79;
        System.out.println(ages[3]);

        final int a = 10; // byte, short, int, float, long, double, char, boolean
        // Non primitive = String, Arrays - sizes



    }
}
