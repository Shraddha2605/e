package src.may.ex_01052024;

public class Lab128 {
    public static void main(String[] args) {
        // {} , new
        int a[] = {27,31,32,34};
        System.out.println(a.length);
        //int[] a2 = {27,31,32,34};

        // How to print all the elements
        // Loop?
        // for
        for (int i = 0; i < a.length; i++) { // 0,1,2,3
            System.out.println(a[i]);
        }

    }
}
