package src.may.ex_01052024;

public class Lab130 {
    public static void main(String[] pramod) {
        int[] int_array = {34,45,43};
        long[] l_array  = {34l, 45l,43l};
        float[] f_array = {45.56f, 32.34f, 43.43f};
        double[] d_array = {34.3, 43.4, 12.32};

        boolean[] b_array = {true,false,true,false};
        char[] c_array = {'A','B','D'};
        String names[] = {"Pramod","Amit","Alok"};
        String[] args = {"Pramod","Amit","Alok"};

        String s1 = "Pramod";
        System.out.println(s1.length());
        System.out.println(names.length);



    }
}
