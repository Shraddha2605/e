package src.may.ex_01052024;

public class Lab129 {
    public static void main(String[] args) {
        int atb6x_students_salaries[]  = {30,0,50,65,90,112,56,27,60,60};
        // double my salary
        for (int i = 0; i < atb6x_students_salaries.length; i++) {
            System.out.println(atb6x_students_salaries[i]*2);
        }
    }
}
