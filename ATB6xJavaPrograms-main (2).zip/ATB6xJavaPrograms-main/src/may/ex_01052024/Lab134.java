package src.may.ex_01052024;

public class Lab134 {
    public static void main(String[] args) {

        int [] a = {1,2,3};
        System.out.println(a[10]); // ArrayIndexOutOfBoundsException


    }
}
