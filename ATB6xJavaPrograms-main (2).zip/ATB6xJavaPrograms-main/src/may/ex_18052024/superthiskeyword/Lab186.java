package src.may.ex_18052024.superthiskeyword;

public class Lab186 {
    public static void main(String[] args) {

    }
}

class P{
    void m1(){
        System.out.println("M1");
    }
    void m2(){
        m1();
        System.out.println("M2");
    }
}