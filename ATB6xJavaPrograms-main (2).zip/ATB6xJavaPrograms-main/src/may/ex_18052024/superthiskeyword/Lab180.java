package src.may.ex_18052024.superthiskeyword;

public class Lab180 {
    // super()
    //1. Use of super with Variables
    //2. Use of super with Methods
    //3. Use of super with constructors

    // Constructor Chaining

    // Encapsulation
    // Polymorphism
    // Abstraction
    // Access Modifiers
    // Static Keyword

}
