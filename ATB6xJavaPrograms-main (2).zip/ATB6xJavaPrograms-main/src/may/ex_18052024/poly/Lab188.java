package src.may.ex_18052024.poly;

public class Lab188 {
    // Polymorphism
}
