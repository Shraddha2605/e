package src.may.ex_18052024.poly.methodoveridding;

public class Hound extends Dog{

    @Override
    void bark(){
        System.out.println("I am Hound, I will Sniff!!");
    }
}
