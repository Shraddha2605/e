package src.may.ex_18052024.poly.methodoveridding;

public class Dog {
    void bark(){
        System.out.println("I am Dog, i will Bark!!");
    }
}
