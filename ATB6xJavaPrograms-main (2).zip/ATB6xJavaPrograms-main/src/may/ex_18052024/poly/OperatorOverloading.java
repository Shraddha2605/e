package src.may.ex_18052024.poly;

public class OperatorOverloading {
    public static void main(String[] args) {
        System.out.println("Pramod"+10);
        System.out.println(10+10);
        // +,-,/,* all of them should be supported
        // Operator overloading is not supported in Java,
        // C++ - Operator overloading
        // pramod/10, 10/10
    }
}
