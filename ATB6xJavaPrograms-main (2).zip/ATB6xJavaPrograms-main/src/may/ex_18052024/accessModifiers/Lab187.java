package src.may.ex_18052024.accessModifiers;

public class Lab187 {
    // Private
    // Public
    // Protected
    // default
}
