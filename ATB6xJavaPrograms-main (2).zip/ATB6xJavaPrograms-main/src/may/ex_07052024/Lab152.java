package src.may.ex_07052024;

public class Lab152 {
    public static void main(String[] args) {
        // Function - Which we greet the user
        // Name -> Hello Pramod
        sayHello("Pramod");

        // Non Return with no parameter
        // Non return with parameter
        // Return with no parameter
        // Return with parameter



    }

    static void sayHello(String name) {
        System.out.println("Hello, " + name);
    }
}
