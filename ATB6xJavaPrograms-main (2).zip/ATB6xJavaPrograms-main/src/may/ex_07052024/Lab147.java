package src.may.ex_07052024;

public class Lab147 {
    public static void main(String[] args) {
        // Functions
        //  (Methods) Class Separate
        // 1. Don't return anything. - void return
        //  Definition -> Call
        // 2. Return Something
        saySomething(); // Call
        System.out.println("End!!");
    }

    static void saySomething(){ // Define
        System.out.println("Hello, How are You?");
    }

}
