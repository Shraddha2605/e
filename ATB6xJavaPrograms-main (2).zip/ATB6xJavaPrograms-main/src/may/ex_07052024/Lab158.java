package src.may.ex_07052024;

public class Lab158 {
    public static void main(String[] args) {
        returnPIE();
        returnString();
        intf();
        bytef();

    }

    static int intf() {
        return 0;
    }

    static byte bytef() {
        return 127;
    }

    static double returnPIE() {
        return 3.14;
    }

    static String returnString() {
        return "Pramod";
    }


}
