package src.may.ex_07052024;

public class Lab150 {
    public static void main(String[] args) {
        // No Return Type - Functions - define -> call
        // Return Something
        int result = sum_of_two_number();
        System.out.println(result);

    }

    static int sum_of_two_number() {
        return 5+6;
    }
}
