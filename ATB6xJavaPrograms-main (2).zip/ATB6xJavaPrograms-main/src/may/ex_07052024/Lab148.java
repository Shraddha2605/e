package src.may.ex_07052024;

public class Lab148 {
    public static void main(String[] args) {
        System.out.println("Starting");
        f1();
        f1();
        f1();
        f2();
        f2();
        f1();
    }

    static void f1(){
        System.out.println("F1");
    }
    static void f2(){
        System.out.println("F2");
    }
}
