package src.may.ex_07052024;

public class Lab146 {
    public static void main(String[] args) {
        // Functions
        // Block of Code that perform a specific Task.
        // Reused

        int a = 10;
        int b = 40;
        int c = a + b;
        System.out.println(c);


        double result = Math.pow(2,3);
        System.out.println(result);


    }


}
