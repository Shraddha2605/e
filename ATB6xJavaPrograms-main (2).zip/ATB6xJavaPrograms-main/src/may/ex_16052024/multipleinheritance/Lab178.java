package src.may.ex_16052024.multipleinheritance;

public class Lab178 {
    public static void main(String[] args) {
        Child c= new Child();
        //c.home();
    }
}
