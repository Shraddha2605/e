package src.may.ex_16052024.multipleinheritance;

public class Child { // extends Father,Mother {

    // Diamond Problem
    // Home - Mother, Father -> Child is confused which one should I go with
    //

}
