package src.may.ex_16052024.multipleinheritance;

public class Mother {
    void home(){
        System.out.println("3BHK");
    }
}
