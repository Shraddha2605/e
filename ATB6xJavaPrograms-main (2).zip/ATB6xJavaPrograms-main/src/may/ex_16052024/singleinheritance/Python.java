package src.may.ex_16052024.singleinheritance;

public class Python extends Programming  {
}
