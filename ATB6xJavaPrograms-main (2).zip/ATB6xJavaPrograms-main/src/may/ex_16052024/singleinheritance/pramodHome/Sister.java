package src.may.ex_16052024.singleinheritance.pramodHome;

public class Sister {

}
