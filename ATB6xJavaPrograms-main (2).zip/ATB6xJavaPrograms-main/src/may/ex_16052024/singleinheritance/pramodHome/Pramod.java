package src.may.ex_16052024.singleinheritance.pramodHome;

public class Pramod extends Father{
//    void bhk2(){
//        System.out.println("[Pramod] 3BHK Now");
//    }



}
