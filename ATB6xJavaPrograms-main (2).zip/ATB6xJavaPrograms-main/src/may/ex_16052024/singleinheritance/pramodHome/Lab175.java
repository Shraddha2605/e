package src.may.ex_16052024.singleinheritance.pramodHome;

public class Lab175 {
    public static void main(String[] args) {
        Pramod pRef = new Pramod();
        pRef.bhk2();

        Sister s = new Sister();
        // s.bhk2();

    }
}
