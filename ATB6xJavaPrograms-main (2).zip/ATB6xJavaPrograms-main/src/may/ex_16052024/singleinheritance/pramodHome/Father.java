package src.may.ex_16052024.singleinheritance.pramodHome;

public class Father {
    public void bhk2(){
        System.out.println("Father 2BHK House");
    }

    private void island(){

    }

}
