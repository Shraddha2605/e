package src.may.ex_16052024.singleinheritance;

import src.may.ex_16052024.singleinheritance.pramodHome.Father;

public class OutSdiePramod {
    public static void main(String[] args) {

        Father fa = new Father();
        fa.bhk2();

    }
}
