package src.may.ex_16052024.multilevelinheritance;

public class Father extends GrandFather{
    void home(){
        System.out.println("2BHK");

    }

    void extra(){
        System.out.println("Extra");
    }
}
