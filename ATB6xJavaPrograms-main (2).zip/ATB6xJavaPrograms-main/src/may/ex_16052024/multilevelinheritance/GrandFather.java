package src.may.ex_16052024.multilevelinheritance;

public class GrandFather {
    void home(){
        System.out.println("1BHK");
    }
}
