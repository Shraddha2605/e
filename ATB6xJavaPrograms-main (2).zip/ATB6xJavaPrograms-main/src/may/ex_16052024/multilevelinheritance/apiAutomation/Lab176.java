package src.may.ex_16052024.multilevelinheritance.apiAutomation;

import src.may.ex_16052024.singleinheritance.pramodHome.Father;

public class Lab176 extends Father {
    void house(){
        bhk2();
    }
}
