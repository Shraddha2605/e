package src.may.ex_16052024.multilevelinheritance.apiAutomation;

public class CommonToAll {
    void openExcelFile(){
        // Write a full prgram to fetch the excel file here in future.

    }
    int API_VERSION = 90;

    void openJSON(){
        System.out.println("CommonToAll");
    }
}
