package src.may.ex_16052024.multilevelinheritance.apiAutomation;

public class BaseTest extends CommonToAll {
    void openSQLConnection(){}
    int VERSION = 88;

    void openJSON(){
        System.out.println("BaseTest");
    }


}
