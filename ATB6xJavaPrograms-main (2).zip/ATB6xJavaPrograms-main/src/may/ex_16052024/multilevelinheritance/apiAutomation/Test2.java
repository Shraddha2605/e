package src.may.ex_16052024.multilevelinheritance.apiAutomation;

public class Test2 extends BaseTest {
    void acc(){
        openExcelFile();
        openSQLConnection();
    }
}
