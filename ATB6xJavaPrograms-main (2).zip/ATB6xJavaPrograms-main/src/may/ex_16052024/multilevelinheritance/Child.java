package src.may.ex_16052024.multilevelinheritance;

public class Child extends Father{
    void home(){
        System.out.println("3BHK");
    }
}
