package src.may.ex_16052024.hierachicalinheritance;

public class Pramod extends Father{
    void h2(){
        home();
    }
}
