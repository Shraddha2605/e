package src.may.ex_16052024.hierachicalinheritance;

public class Ruhani extends Father {
    void h1(){
        home();
    }
}
