package src.may.ex_16052024.hierachicalinheritance;

public class Father {
    void home(){
        System.out.println("3BHK");
    }
}
