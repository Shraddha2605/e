package src.may.ex_16052024.hierachicalinheritance;

public class Lucky extends Father {
    void h1(){
        home();
    }
}
