package src.may.ex_16052024.hierachicalinheritance.ex1;

public class Truck extends Vehicle {

    Truck() {
        System.out.println("Truck");
    }

}