package src.may.ex_16052024.hierachicalinheritance.ex1;

public class Lab179 {
    public static void main(String[] args) {
//
//        Car c = new Car();
//        c.vehicleHasTopSpeed();

        Vehicle v1 = new Car();
        v1.vehicleHasTopSpeed();



    }
}
