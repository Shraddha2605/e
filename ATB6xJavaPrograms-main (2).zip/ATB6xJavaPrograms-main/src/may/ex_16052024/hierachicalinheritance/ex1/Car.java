package src.may.ex_16052024.hierachicalinheritance.ex1;

public class Car extends Vehicle{
    Car(){
        System.out.println("Car");
    }
}