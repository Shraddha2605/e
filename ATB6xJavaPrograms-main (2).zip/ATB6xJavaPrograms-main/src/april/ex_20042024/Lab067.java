package src.april.ex_20042024;

public class Lab067 {
    public static void main(String[] args) {
        double sq = Math.sqrt(2);
        System.out.println(sq);
    }
}
