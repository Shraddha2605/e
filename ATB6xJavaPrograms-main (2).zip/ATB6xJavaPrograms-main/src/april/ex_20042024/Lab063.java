package src.april.ex_20042024;

public class Lab063 {
    public static void main(String[] args) {
        String API_TOKEN = "0xa0d8s8d9ds";
        String password = new String("ATB@123");

    }
}
