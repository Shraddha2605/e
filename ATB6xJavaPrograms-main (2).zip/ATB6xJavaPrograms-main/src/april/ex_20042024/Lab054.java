package src.april.ex_20042024;

public class Lab054 {
    public static void main(String[] args) {
        String name = "Pramod";
        // How they are different?
        // String - immutable in nature?
        // Strings are immutable , non-primitive data types in Java.
        // Immutable - that can't be change.
        name = "Dutta";


    }
}
