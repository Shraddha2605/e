package src.april.ex_20042024;

public class Lab060 {
    public static void main(String[] args) {
        String s1 = new String("pramod");
        String s2 = new String("pramod");
        String s3 = new String("pramod");
        System.out.println(s1 == s2);
        System.out.println(s1.equals(s2));


        System.out.println(" 000 ");
        String a1 = "P";
        String a2 = "P";
        System.out.println(a1 == a2);
        System.out.println(a1.equals(a2));


    }
}
