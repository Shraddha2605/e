package src.april.ex_20042024;

public class Lab050 {
    public static void main(String[] args) {
        byte b  = 10;
        int a = b; // Type Casting this? - >Implicit JVM
        int a1 = (int)b; // Explicit Casting

    }
}
