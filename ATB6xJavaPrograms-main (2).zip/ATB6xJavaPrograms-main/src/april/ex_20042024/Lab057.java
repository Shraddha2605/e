package src.april.ex_20042024;

public class Lab057 {
    public static void main(String[] args) {
        final String API_TOKEN = "0a9s890ds98ds9";


    }
}
