package src.april.ex_20042024;
//import java.lang.*;


public class Lab062 {
    public static void main(String[] args) {
        String s1 = "pramod";
        // int a = new int(8);
        // new op -> Non Primitive Types - String, Arrays, Class.. more will come

    }
}
