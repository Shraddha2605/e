package src.april.ex_20042024;

public class Lab051 {
    public static void main(String[] args) {
        int a = 87;
        long b = 91;
        String s1 = "KK";
        String s2 = "VV";
        //System.out.println(s1+s2+a+b);
        System.out.println(s1+s2+(a+b));
        // BODMAS - Bracets, of div, mul, add, sub
    }
}
