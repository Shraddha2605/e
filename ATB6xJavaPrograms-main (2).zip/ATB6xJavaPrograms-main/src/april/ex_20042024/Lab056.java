package src.april.ex_20042024;

public class Lab056 {
    public static void main(String[] args) {

        String name = "The Testing Academy";
        String name1 = "The Testing Academy";

        String name2  = new String("The Testing Academy"); // Heap Area(OA)


    }
}
