package src.april.ex_20042024;

public class Lab055 {
    public static void main(String[] args) {
        String s1 = "Pramod";
        String s2 = s1;
        System.out.println(s2);

        System.out.println( " --- ");

        String s3 = "TheTestingAcademy";
        s3.toLowerCase();
        System.out.println(s3);


    }
}
