package src.april.ex_20042024;

public class Lab052 {
    public static void main(String[] args) {
        String name = "Pramod";
        // String?
        // Bunch of Chars - Collection of Chars
        // Class -> What is Class??
        // Class -> provides some extra f(n).
        System.out.println("Your name is -> "+ name);



    }
}
