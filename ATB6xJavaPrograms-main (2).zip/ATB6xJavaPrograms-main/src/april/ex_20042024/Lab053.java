package src.april.ex_20042024;

public class Lab053 {
    public static void main(String[] args) {
        String name = "Pramod"; // Assignment Operators
//        String name2 = new String("Pramod"); // New Operator
        // Both of them, actually save the name, name2 in different ways JVM
        // How they store the values in the JVM?

        System.out.println(name);
        System.out.println("Your name is -> "+name);
        System.out.printf("Your name is -> %s",name);

        System.out.println("\n -- All the Functions avaiable in String -- ");

        System.out.println(name.length());
        System.out.println(name.toLowerCase());
        System.out.println(name.toUpperCase());

        int age = 65;
        char c = 'a';
        boolean b= true;

        // Primitive Data Types - byte, int,long, short, double, float, char, boolean
        // All of them don't have extra functionality
        // OOPs - Object oriented - primitive
        // OOPs - everything is class.
        // OOPs - Fully - don't have anything which is not in class format/ primitive
        // Java is not pure Object oriented.


        // Non-Primitive Data Type
        // String - Extra functionalities.







    }
}
