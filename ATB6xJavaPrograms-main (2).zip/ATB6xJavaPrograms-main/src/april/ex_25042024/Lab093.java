package src.april.ex_25042024;

public class Lab093 {
    public static void main(String[] args) {
        int a = 11;
        switch (-1){
            default:
                System.out.println("Default");
                break;
            case -1:
                System.out.println("10");
                break;
            case 9:
                System.out.println("10");
                break;
        }

        System.out.println();
        //syso
    }
}
