package src.april.ex_25042024;

public class Lab085 {
    public static void main(String[] args) {
        byte b=20;
        switch(b){
            case 10:
                System.out.println("TEN");
                break;
            case 127:
                System.out.println("ONE TWENTY EIGHT");
                break;
            default:
                System.out.println("Default");
        }


    }
}
