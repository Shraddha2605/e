package src.april.ex_25042024;

public class Lab084 {
    public static void main(String[] args) {
        int a=98;
        switch(a){
            case 98:
                System.out.println("Val - 98");
//            case 98:
//                System.out.println("Val - 98");
        }
    }



}
