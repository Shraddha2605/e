package src.april.ex_25042024;

public class Lab083 {
    public static void main(String[] args) {
        int a = 10;
        switch (a) {

        }
        char ch = 'A'; // 65
        switch (ch) {
        }
        float f = 30.0F;
        switch ((int) f) { // Narrow - Type casting Explicit
        }


        double d=30.0;
        switch((int) d){ }


//        boolean b = true;
//        switch(b){ }

        long a11=30l;
        switch((int)a11){ }




    }
}
