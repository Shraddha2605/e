package src.april.ex_25042024;

public class Lab088 {
    public static void main(String[] args) {
        //(10 - 4) + 3 *4
        System.out.println((10 - 4) + 3 *4);
        System.out.println(200 / 50 + (3 * 4));



    }
}
