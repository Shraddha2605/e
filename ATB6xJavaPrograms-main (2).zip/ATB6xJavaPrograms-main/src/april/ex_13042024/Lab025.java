package src.april.ex_13042024;

public class Lab025 {
    public static void main(String[] args) {

        int num1 = 67;
        int num2 = 89;
        System.out.println(num2 + num1);

        String firstname = "PRAMOD";
        String lastname = "DUTTA";
        System.out.println(firstname + lastname);


        // Unary
        int a1 = +10;
        int a2 = -10;
        System.out.println(a1);
        System.out.println(a2);




    }
}
