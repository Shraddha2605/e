package src.april.ex_13042024;

public class Lab015 {
    public static void main(String[] args) {

//        System.out.print("Hi"); // Will not add next line
//        System.out.println("Hi"); // Will add next line
        int age = 98;
        // %d ->  any integer - byte, short, int or long
        // %s -> String
        // %c -> char
        // %f -> float
        System.out.printf("Ritesh age is %d",age);
    }
}
