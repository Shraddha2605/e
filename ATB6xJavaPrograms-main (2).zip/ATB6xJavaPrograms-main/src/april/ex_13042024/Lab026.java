package src.april.ex_13042024;

public class Lab026 {
    public static void main(String[] args) {
        byte a = 10;
        byte b = 18;
        System.out.println(a+b);
    }
}
