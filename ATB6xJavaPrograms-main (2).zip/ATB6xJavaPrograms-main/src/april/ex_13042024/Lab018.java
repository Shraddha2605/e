package src.april.ex_13042024;

public class Lab018 {
    public static void main(String[] args) {
        // name ?
        // Non Primitive
        String name = "Pramod";
        System.out.println(name);
        System.out.printf("Your name is -> %s",name);



    }
}
