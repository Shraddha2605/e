package src.april.ex_13042024;

public class Lab024 {
    public static void main(String[] args) {
//        int enum = 45;
        int Enum = 45;

        char c = '\n'; // New line / Next Line
        char c1 = '\t'; // Add Tab
        char c2 = '\b'; // Backlash, delete 1 char
        char c3 = '\r'; // Backlash, delete 1 char
        System.out.println("Pramod" + c3 + "Dutta");
        System.out.println("Pramod\tDutta");
        System.out.println("Pramo\"d");
        System.out.println("Pramo\'d");


    }
}
