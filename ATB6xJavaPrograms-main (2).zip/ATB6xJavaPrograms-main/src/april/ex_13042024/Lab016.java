package src.april.ex_13042024;

public class Lab016 {
    public static void main(String[] args) {
        int number = 9;
        System.out.printf("Your number is -> %d", number);
        System.out.println();
        System.out.println("Your number is -> " + number);
        // Your number is -> 9

        float pi = 3.14159f;
        System.out.printf("Your value is  %f",pi);
    }
}
