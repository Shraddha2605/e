package src.april.ex_13042024;

public class Lab010 {
    public static void main(String[] args) {
        System.out.println("Variables");

        // data_type variable_name = variable_value(literal)

        // Java ->
        // Primitive Data Type
        // byte, short, int, long, char
        // float, double
        // boolean - true and false



        // Non primitive Data Types
        // String, Arrays, Class


        // This name identifier - variable_name
        // Rule 1- Unique
        // int age = 54;

        // Rule 2 - No Keywords
        //int static = 66;

        // Rule 3 - A-Z, a-z, $,_ starts
        int a = 66;
        int Z = 66;
        int $ = 66;
        int _ = 66;
        int $_age = 66;
        int $_age2 = 66;
//        int 1name  = 34;
        // int 123_name  = 34;
//        int #1  = 34;

//        int age = 65;
//        byte age = 78;
//








    }
}
