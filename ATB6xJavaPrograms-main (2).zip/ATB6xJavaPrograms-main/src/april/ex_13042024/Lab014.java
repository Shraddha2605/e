package src.april.ex_13042024;

public class Lab014 {
    public static void main(String[] args) {
        // Maths Table
        // Table of 9
        System.out.println("9x1=9");
        System.out.println("9x2=18");
        System.out.println("9x10=90");
    }
}
