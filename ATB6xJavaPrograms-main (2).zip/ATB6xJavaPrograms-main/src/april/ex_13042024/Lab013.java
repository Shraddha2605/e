package src.april.ex_13042024;

public class Lab013 {
    public static void main(String[] args) {
        int _123 = 987;
        System.out.println(_123);
    }
}
