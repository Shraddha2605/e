package src.april.ex_13042024;

public class Lab022 {
    public static void main(String[] args) {
        int age = 65;
        // Assignment Operator - assign the value of right to left.
        // age = 65;

        // Arithmetic Operator
        double a = 10;
        double b = 34;
        double sum = a+b;
        System.out.printf("Sum is %f",sum);
        System.out.println();
        double sub = a-b;
        System.out.println(sub);
        double mul = a*b;
        System.out.println(mul);
        double div = a/b; // 10/34 -> 0.29 -> 0 nad 0.29
        System.out.println(div);


    }
}
