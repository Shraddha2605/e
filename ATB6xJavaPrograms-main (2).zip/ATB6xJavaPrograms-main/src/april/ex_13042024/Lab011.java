package src.april.ex_13042024;

public class Lab011 {
    public static void main(String[] args) {
        // data_type identifier(variable_name) = variable_value(literal)

        // Primitive data types - That can't be further broken
        // byte, short, int, long, char - Size, Range
        // float, double
        // boolean - true and false

        // Non-Primitive Type ( After some time)
        // String, Class, Arrays ( Can be broken)

        // byte ( -128 to 127)

        byte b = -128; // Size, Range
//        byte b2 = -200;
        byte b3 = -1;
//        byte b4 = 127;
//        b4 = b4+1;

        short s = -31567;
        short s2 = -1;
//        short s3 = 33678;


        // Interview Q -








    }
}
