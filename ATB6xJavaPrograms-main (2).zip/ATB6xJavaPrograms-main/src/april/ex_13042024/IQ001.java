package src.april.ex_13042024;

public class IQ001 {
    public static void main(String[] args) {
        // Store the Age ?
        byte age1 = 123;
        short age2 = 65;
        int age3 = 65;
        long age4= 65L;

        // Phone Number -
        long phone_number = 9876543210l;
        long phone_number2 = 9876543210L;

        float pi = 3.14f;
        float pi_ = 3.14F;

        double d = 1.2345679876;



    }
}
