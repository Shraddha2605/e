package src.april.ex_13042024;

public class IQ002 {
    public static void main(String[] args) {

        char c = 'A';
        System.out.println(c);

        char c1 = '$';
        System.out.println(c1);

        char c2 = '\n';
        System.out.println(c2);

        char c3 = '\u1F6A';
        System.out.println(c3);
        // :), :(, :D .;) -> unicode chars


    }
}
