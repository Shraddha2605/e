package src.april.ex_13042024;

public class IQ003 {
    public static void main(String[] args) {
        int a = 10;
        int b = 45;
        System.out.println(a+b);
        // Interview - left -> right
        String name = "Pramod";
        System.out.println(a+name);
        System.out.println(name+a);


        System.out.println(a+b+name);

        // All the + below are concatenation
        System.out.println(name+a+b);



    }
}
