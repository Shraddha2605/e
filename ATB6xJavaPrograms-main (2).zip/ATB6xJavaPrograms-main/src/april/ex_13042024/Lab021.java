package src.april.ex_13042024;

public class Lab021 {
    public static void main(String[] args) {
        int age = 65;
        // literal - 65
        String name = null;
        String name2 = "Pramod";

    }
}
