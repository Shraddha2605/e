package src.april.ex_13042024;

public class Lab023 {
    public static void main(String[] args) {
        double a = 34;
        double b = 10;
        double result = a%b;
        System.out.println(result);

        // 10 |  34 | Q -3
        //    | 30  |
        // -------------
        // R -> 4


        // 78%12
        //        12 | 78 | 6 - Q
//           |  72 |
//               6 - Remainder


        int  num = 38;
        int r = num%2;
        System.out.println(r);

        // Comparator Op.

        // num%2 == 0 -> Even
        // num%2 == 1 -> Odd





    }
}
