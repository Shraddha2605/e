package src.april.ex_13042024;

public class Lab020 {
    public static void main(String[] args) {
        // ASCII Table
        // 0-9 48-57
        // A-Z 65-90
        // a-z 97-122
//      // 0-9 48-57

        int age = 10; // Decial
        int b = 0b101; // Binary
        int octal = 0101; // If your Automation you may be working with these numbers
        int hex = 0Xface;


    }
}
