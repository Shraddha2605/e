package src.april.ex_13042024;

public class Lab017 {
    public static void main(String[] args) {
        byte b = 10;
        short s= 128;
        int i = 128;
        short i1 = 128;
        i1 = 34;
        i1 = 89;
        i1 = 99;
        System.out.println(i1);

    }
}
