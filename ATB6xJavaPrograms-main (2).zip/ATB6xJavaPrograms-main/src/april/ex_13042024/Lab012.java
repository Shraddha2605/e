package src.april.ex_13042024;

public class Lab012 {
    public static void main(String[] args) {
     boolean isMale = true;
     boolean isPramodMale = false;
//     boolean isPramodMale2 = False;

        char grade = 'A';
        char grade_kusum = 'E';
        char grade_wswati = 'B';
        char c = '!';
        char c2 = '@';
        char _123 = 'N';
//        char _1234 = "N";
        System.out.println(_123);





    }
}
