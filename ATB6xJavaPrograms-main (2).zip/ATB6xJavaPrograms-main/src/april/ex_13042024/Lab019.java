package src.april.ex_13042024;

public class Lab019 {
    public static void main(String[] args) {
        final float pi = 3.145f;
        final int pi_int = 19;
//        pi_int = 89;
//        pi = 10.89f;
        System.out.println(pi);



    }
}
