package src.april.ex_13042024;

public class Lab009 {
    public static void main(String[] args) {
        System.out.println("Variables");

        // data_type variable_name = variable_value(literal)

        // Java ->
        // Primitive Data Type
        // byte, short, int, long, char
        // float, double
        // boolean - true and false



        // Non primitive Data Types
        // String, Arrays, Class

        int age = 66;
        age = 65;
        System.out.println(age);





    }
}
