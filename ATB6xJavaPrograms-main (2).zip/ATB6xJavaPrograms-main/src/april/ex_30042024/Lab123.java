package src.april.ex_30042024;

public class Lab123 {
    public static void main(String[] args) {
        // Do Prime Number and FizzBuzz

    }
}
