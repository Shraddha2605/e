package src.april.ex_18042024;

public class Lab029 {
    public static void main(String[] args) {
        int a = 10;
        int b = 45;
        System.out.println(a+b);
        String name = "Pramod";
        System.out.println(a+name);
        System.out.println(name+a);
        // Concatenation - String + other
        System.out.println(a+b+name);

        // All the + below are concatenation
        System.out.println(name+a+b);


    }
}
