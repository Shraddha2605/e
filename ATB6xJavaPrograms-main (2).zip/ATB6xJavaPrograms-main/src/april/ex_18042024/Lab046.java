package src.april.ex_18042024;

public class Lab046 {

    public static void main(String[] args) {
        // Increment Operator
        // Pre and Post
        // a= a+1;
        int a = 10;
        // Result, a
        int result = a++; //
        // Result -> 10
        //a -> 11
        System.out.println(result);
        System.out.println(a);



    }

}
