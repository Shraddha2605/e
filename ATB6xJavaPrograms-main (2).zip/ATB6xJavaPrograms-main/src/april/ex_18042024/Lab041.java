package src.april.ex_18042024;

public class Lab041 {
    public static void main(String[] args) {
        // Casting -? Mold
        byte b = 10;
        //int a = (int)b; // Implicit Casting -> JVM ( You don't have to specify)
        int a = (int) b; // Explicit Casting -> JVM
    }
}
