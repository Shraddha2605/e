package src.april.ex_18042024;

public class Lab048 {
    public static void main(String[] args) {

        int a = 10;
        System.out.println(++a + ++a);
        // Part A -> ++a , EP_Result = 11, a = 11
        // Part B  -> + , EP_Result, a
        // Part C  -> ++a, EP_Result = 12, a = 12


    }
}
