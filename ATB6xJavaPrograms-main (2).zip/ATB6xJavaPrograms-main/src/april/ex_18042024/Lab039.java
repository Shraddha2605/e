package src.april.ex_18042024;

public class Lab039 {
    public static void main(String[] args) {
        int a = 90;
        int b = 90;
        boolean c = (a <= b);
        System.out.println(c);


    }
}
