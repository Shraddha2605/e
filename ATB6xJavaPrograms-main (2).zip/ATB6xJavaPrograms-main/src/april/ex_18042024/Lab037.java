package src.april.ex_18042024;

public class Lab037 {
    public static void main(String[] args) {
        // BIO
        int a = 12;
        boolean b = !(a > 10 || a < 5);
        // boolean b = false;
        System.out.println(b);

    }
}
