package src.april.ex_18042024;

public class Lab044 {
    public static void main(String[] args) {

        // Increment (++) / Decrement (--) Operators

        // pre, post

        // pre -> Value is incremented first and then the result is computed.

        int a = 10;
        // ++a -> a = a+1 (value increase first -> assign the value)

        int b = ++a; //  a  = a+1

        // b = 11
        // a = 11

        System.out.println(b);
        System.out.println(a);





    }
}
