package src.april.ex_18042024;

public class Lab034 {
    public static void main(String[] args) {
        // Logical Operator
        // Not Gate, OR Gate, And Gate

        boolean a = true;
        System.out.println(!a);
        System.out.println(!(10>20));
        System.out.println(!(30>90));
        System.out.println(!!(30>90));
        System.out.println(!!!(30>90));
        System.out.println(!!!!(30>90));
       //  System.out.println((30>90)!);


    }
}
