package src.april.ex_18042024;

public class Lab031 {
    public static void main(String[] args) {
        // Relational Operators -> boolean
        // >, < >=,<=, == , != ( ! = )
        int age_mamitha = 30;
        int age_pramod = 34;
        boolean result = age_pramod > age_mamitha;
        System.out.println(result);



    }
}
