package src.april.ex_18042024;

public class Lab030 {
    public static void main(String[] args) {
        // Compound Assignment Operators
        int a = 10;
        int b = 45;

        // += , -=, /=, *= . %=
        //b = b + 30;
        b +=30; // b= b+ 30;
        System.out.println(b);


        int b1 = 90;
        b1 -= 89; // b1 = b1 - 89; -> 1
        System.out.println(b1);


    }
}
