package src.april.ex_18042024;

public class Lab047 {

    public static void main(String[] args) {
        int a= 10;
//        System.out.println(++a);
        System.out.println(a++);
        // result -> 10
        // a -> 11
        System.out.println(a);


        //        int a = 10;
//        System.out.println(++a);
//        // Pre Incremet
//        // ++ in front variable like a -> pre ->
//        // do increment first then print


        int a1 = 10;
        System.out.println(a1++);
        System.out.println(a1);
        // Post Increment
        // ++ after variable like a++ -> post ->
        // first print, do increment





    }

}
