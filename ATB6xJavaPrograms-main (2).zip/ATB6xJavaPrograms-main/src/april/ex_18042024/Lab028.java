package src.april.ex_18042024;

public class Lab028 {
    public static void main(String[] args) {
        // Arithmetic Operators
        int a = 10;
        int b = 20;
        System.out.println(b+a);
        System.out.println(b-a);
        System.out.println(b*a);
        System.out.println(b/a);
        System.out.println(b%a); // Modulus -> Remainder

    }
}
