package src.april.ex_18042024;

public class Lab033 {
    public static void main(String[] args) {

        System.out.println( 10 == 10); // ==
        System.out.println( 10 >= 10); //  10> 10 or 10 = 10
        System.out.println( 10 <= 10); // 10 < 10 or 10 = 10
        System.out.println( 10 > 10);
        System.out.println( 10 < 10);

        System.out.println(" -------");
        System.out.println('A');
        System.out.println('A' == 65);
        System.out.println('A' != 65);

        // == -> condition equal values


        // System.out.println('A' = 65.2);
        System.out.println('A' == 65.2);

        // System.out.println(true >= true);




    }
}
