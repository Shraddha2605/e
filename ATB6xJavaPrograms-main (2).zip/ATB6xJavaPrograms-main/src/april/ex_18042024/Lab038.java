package src.april.ex_18042024;

public class Lab038 {
    public static void main(String[] args) {

        int a = 67;
        boolean b = !(false);
        System.out.println(b);

    }
}
