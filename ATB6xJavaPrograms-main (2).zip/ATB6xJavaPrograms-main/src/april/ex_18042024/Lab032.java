package src.april.ex_18042024;

public class Lab032 {
    public static void main(String[] args) {

        int a = 10;
        int b = 10;
        boolean c = (10 >= 10);  // 10 > 10 or 10 = 10
        // OR gate -> ?
        // >= --> > =
        System.out.println(c);


    }
}
