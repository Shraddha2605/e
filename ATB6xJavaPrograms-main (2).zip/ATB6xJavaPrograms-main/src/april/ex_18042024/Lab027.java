package src.april.ex_18042024;

public class Lab027 {
    public static void main(String[] args) {
        int age = 65; // unary plus
        int num = -1; // unary plus - only 1 operand
        System.out.println(age+num);
    }
}
