package src.april.ex_18042024;

public class Lab043 {
    public static void main(String[] args) {
        int course = 100;
        float GST = 18.45f; //18
        double total = course + (int)GST;
        System.out.println(total);


    }
}
