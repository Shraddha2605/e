package src.april.ex_23042024;

public class Lab069 {
    public static void main(String[] args) {
        // age > 18 you can watch the movie
        // You can't wathc the movie

//        if(condition -> boolean true or false) // This is keyword
//        {}
//        else{
//
//        }

        int age = 13;
        if (age > 18){
            System.out.println("You can watch the Movie A");
        }else{
            System.out.println("You can't");
        }


    }
}
