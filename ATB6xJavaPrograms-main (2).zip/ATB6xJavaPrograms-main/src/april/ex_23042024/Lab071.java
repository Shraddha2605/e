package src.april.ex_23042024;

public class Lab071 {
    public static void main(String[] args) {
        boolean b = !true;
        if(b){
            System.out.println("b is true");
        }else {
            System.out.println("b is not true");
        }


    }
}
