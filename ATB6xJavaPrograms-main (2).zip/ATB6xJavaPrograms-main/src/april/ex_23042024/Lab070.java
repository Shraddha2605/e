package src.april.ex_23042024;

public class Lab070 {
    public static void main(String[] args) {
        int a = 10;
        if(a == 4){
            System.out.println("Hi");
        }else{
            System.out.println("Bye");
        }




    }
}
