package src.april.ex_23042024;

public class Lab073 {
    public static void main(String[] args) {
        // Even and Odd Number
        // 7 - odd , 4 - even
        // num%2 == 0 -> even
        // else it is a odd

//        2 | 11| 5 - Q| |
//            10 |
//                1- R

        int num = 11;
        if(num%2 == 0){
            System.out.println("Even");
        }else{
            System.out.println("Odd");
        }





    }
}
