package src.april.ex_23042024;

public class Lab078 {
    public static void main(String[] args) {

        if (true) {
            System.out.println("1");
            if (true) {
                System.out.println("2");
                if (true) {
                    System.out.println("3");
                }
            }
        }


    }
}
