package src.april.ex_23042024;

public class Lab068 {
    public static void main(String[] args) {
            // Max in three Numbers using ?


    }
}
