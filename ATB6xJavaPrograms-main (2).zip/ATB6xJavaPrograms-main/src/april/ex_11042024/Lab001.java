package src.april.ex_11042024;

public class Lab001 {
    public static void main(String[] args) {
       // Single Line Comment - This code will not be executed.
        // Purpose of Comment?

        // Used by Dev/ Automaton to share the documentation
        // This program is lab001 and it covers basics.

       // exit code 0 -> Code is successfully Run.



        /**
         * // Multiple Links
         *  Author - Pramod Dutta
         *  Course Details - ATB6X
         *   adsdadas
         *   dasda
         *
         * **/

    }
}
