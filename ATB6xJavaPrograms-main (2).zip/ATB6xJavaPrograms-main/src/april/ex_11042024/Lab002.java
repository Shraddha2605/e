package src.april.ex_11042024;
/**
 * Author - Pramod
 * Program Name - ATB6x
 *  Lab No - 2
 *  Concept - System , print ln
 *
 *
 */

// Class -> Method -> statements(instructions)



public class Lab002 {
    public static void main(String[] args) {
        System.out.print("Hello Pramod");
        System.out.print("Hello Dutta\t");

        // print -> in the end I will not add  \n - newline
        // println -> add a new line

        System.out.println("Amit");
        System.out.println("Sharma");
    }


}
