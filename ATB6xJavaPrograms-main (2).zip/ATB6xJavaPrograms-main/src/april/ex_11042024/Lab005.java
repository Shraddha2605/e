package src.april.ex_11042024;

public class Lab005 {

    // Class without main method ?
    // Run -> No

}
