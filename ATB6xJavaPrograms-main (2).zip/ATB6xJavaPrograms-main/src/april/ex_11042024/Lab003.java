package src.april.ex_11042024;

// Flow JVM (Interview)
// -> Load the class - Lab003
// -> main Method
// -> execute the statements one by one.


public class Lab003 {
    public static void main(String[] ajay) {
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
    }
}
