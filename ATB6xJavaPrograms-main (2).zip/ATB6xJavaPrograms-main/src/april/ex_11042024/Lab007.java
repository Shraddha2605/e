package src.april.ex_11042024;

public class Lab007 {
    public static void main(String[] args) {
        System.out.println("Hi");
        // package, public, class, static, void
    }
}
