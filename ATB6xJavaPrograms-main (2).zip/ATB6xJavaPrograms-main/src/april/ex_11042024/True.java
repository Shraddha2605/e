package src.april.ex_11042024;

public class True {
}
