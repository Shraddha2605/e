package src.april.ex_11042024.classNames;

public class Class {
}
