package src.april.ex_11042024;

public class smallcase {
    public static void main(String[] args) {
        System.out.println("Hi");
    }
}
