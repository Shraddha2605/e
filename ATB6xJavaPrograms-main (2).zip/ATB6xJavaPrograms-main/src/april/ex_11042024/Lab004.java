package src.april.ex_11042024;

public class Lab004 {
    // public static void main(String[]
    public static void main(String[] a) {
        System.out.println("Interview Q");
    }
}
