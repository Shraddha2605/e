package src.april.ex_11042024;

public class Lab006 {

    // Keyword -> Important - reserved, pre-defined.
    // English ->  Sit down ->  Dog -> Running
    // Blue color in the IntelliJ
    // package, public , class
    // lower case



}
