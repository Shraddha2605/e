package src.april.ex_11042024;

public class Lab008 {
    public static void main(String[] args) {
        System.out.println(2+2);


        // Variables - Value for the this can be changed in the program.
        // name -> pramod
        // name -> lucky
        // name -> dutta

        //Mother -> [] - sugar ->
        int age = 65;
        // Integer type of container storing 65 as value in the variable name-> age
        age = -1;
        age = age +1;
        System.out.println(age);







    }
}
