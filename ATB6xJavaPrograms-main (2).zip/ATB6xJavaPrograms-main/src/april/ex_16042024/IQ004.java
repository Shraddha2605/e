package src.april.ex_16042024;

public class IQ004 {
}
