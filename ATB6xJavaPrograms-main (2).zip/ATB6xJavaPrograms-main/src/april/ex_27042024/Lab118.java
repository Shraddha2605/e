package src.april.ex_27042024;

public class Lab118 {
    public static void main(String[] args) {

        int pramod = 10;
        while(true){
            System.out.println("Hello");
            // Infinite loop  - exit code 130
        }

    }
}
