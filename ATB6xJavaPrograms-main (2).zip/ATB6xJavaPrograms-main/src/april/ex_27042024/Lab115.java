package src.april.ex_27042024;

public class Lab115 {
    public static void main(String[] args) {
        //while
        // A - Init
        // B - Condition
        // C - Incre

        int i = 1; // A
        while (i<=10){ // B
            // Execute the code
            System.out.println(i);
            i++; // C

            // i - 1, 10 , print 1 to 10
        }

        for (int j = 1; j <=10 ; j++) {
            System.out.println(j);
        }

    }
}
