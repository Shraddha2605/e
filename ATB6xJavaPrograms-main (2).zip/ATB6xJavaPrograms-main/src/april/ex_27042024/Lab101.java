package src.april.ex_27042024;

public class Lab101 {
    public static void main(String[] args) {
        for(int j=0;j<5;j++){
            System.out.println(j);
        }
    }
}
