package src.april.ex_27042024;

public class Lab104 {
    public static void main(String[] args) {
        System.out.println("Hi");
        int a=10;
        System.out.println(a);
        // Purpose -> JVM will tell you what happened to you Java program


    }
}
