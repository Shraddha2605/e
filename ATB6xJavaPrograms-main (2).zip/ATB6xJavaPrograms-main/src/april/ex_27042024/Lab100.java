package src.april.ex_27042024;

public class Lab100 {
    public static void main(String[] args) {
        // Condition - If,Else
        // if else if, else - multiple conditions
        // switch  - multiple conditions with Break keyword
        //

        // For Loops and While and Do While
        // Loops
        // to perform a task multiple times
        // print 1 to 10

        System.out.println(1);
        System.out.println(2);
        System.out.println(3);
        System.out.println(4);
        System.out.println(5);
        System.out.println("..");
        System.out.println(10);

        // for(A:B:C)
        // A -> initialization -> Where you want to start. - int i = 0;
        // B -> Condition (When you want to stop) - i < 10
        // C -> How you want to do increment / decrement / updation - i++ , i = i+1

        for (int i = 0; i < 10 ; i++) {
            System.out.println("Code which you want to execute multiple times");
        }

        // 0,1,2,3,4,5,6,7,8,9


    }
}
