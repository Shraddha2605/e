package src.april.ex_27042024;

public class Lab098 {
    public static void main(String[] args) {
        // Program to Check if a Number is Prime or Not
        // Loop also -  from 1 to 100 - Loop

    }
}
