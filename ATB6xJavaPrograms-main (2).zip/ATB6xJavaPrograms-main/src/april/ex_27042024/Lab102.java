package src.april.ex_27042024;

public class Lab102 {
    public static void main(String[] args) {
        for (int i = 1; i <= 5 ; i++) {
            System.out.println(i);
        }
        //1,2,3,4,5
    }
}
