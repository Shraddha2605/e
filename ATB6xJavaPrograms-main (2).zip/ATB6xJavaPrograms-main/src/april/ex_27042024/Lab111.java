package src.april.ex_27042024;

public class Lab111 {
    public static void main(String[] args) {

        for (int i = 1; i <= 50; i++) {
            if (i % 2 == 0) {
                System.out.println("Even Numbers -> " + i);
            }
        }


    }
}
