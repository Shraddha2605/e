package src.april.ex_27042024;

public class Lab105 {
    public static void main(String[] args) {

//        final boolean b1 = true;
//        for(float f=0;b1;){
//            System.out.println("Hi");
//        }

        // for( A ;B ; C)
        // A -> Initialization -> JVM What variable, where you are starting point
        // B - Condition -> When you want this to stop. -> true, false
        // C ->  Increment / Decrement

        for(;;){

        }

    }
}
