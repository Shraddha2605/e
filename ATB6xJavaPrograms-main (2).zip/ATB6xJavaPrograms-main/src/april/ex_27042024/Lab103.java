package src.april.ex_27042024;

public class Lab103 {
    public static void main(String[] args) {

        // for( A ;B ; C)
        // A -> Initialization -> JVM What variable, where you are starting point
        // B - Condition -> When you want this to stop.
        // C ->  Increment / Decrement

        // ICID ->
        for(int i=1; i<=10;i++){
            System.out.println("Pramod");
        }



    }
}
