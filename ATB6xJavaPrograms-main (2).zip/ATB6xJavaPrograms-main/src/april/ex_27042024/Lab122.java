package src.april.ex_27042024;

public class Lab122 {
    public static void main(String[] args) {

        int i = 10;
        do {
            System.out.println(i);
            i++;
        } while (i < 10);


        while(i < 10){
            System.out.println(i);
            i++;
        }
    }
}
