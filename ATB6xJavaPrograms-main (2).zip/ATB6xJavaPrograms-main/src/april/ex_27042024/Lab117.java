package src.april.ex_27042024;

public class Lab117 {
    public static void main(String[] args) {
       // for (int i = 1; i <=10; i=i*2) {
        for (int i = 1; i <=10; i=i+2) {
            System.out.println(i);
        }
    }
}
