package src.april.ex_27042024;

public class Lab108 {
    public static void main(String[] args) {
        for (int i = 0; i < 10 ; i++) {
            System.out.println("Pramod");
        }

        for (int i = 1; i <= 10 ; i++) {
            System.out.println("Pramod");
        }

        // | i=0 , 1 |
        // | i=1 , 2 |
        // | i=2 , 3 |
        // | i=3 , 4 |
        // | i=4 , 5 |
        // | i=5 , 6 |
        // | i=6 , 7 |
        // | i=7 , 8 |
        // | i=8 , 9 |
        // | i=9 , 10 |

        for (int i = 1; i <= 10 ; i++) {
            System.out.println("Pramod");
        }

        // | i=1 , 1 |
        // | i=2 , 2 |
        // | i=3 , 3 |
        // | i=4 , 4 |
        // | i=5 , 5 |
        // | i=6 , 6 |
        // | i=7 , 7 |
        // | i=8 , 8 |
        // | i=9 , 9 |
        // | i=10 , 10 |



    }
}
