package src.april.ex_27042024;

public class Lab106 {
    public static void main(String[] args) {

        for (double i = 1.1; i < 12.30; i++) {
            System.out.println(i);
        } // numberal - float, int, short, byte

    }
}
