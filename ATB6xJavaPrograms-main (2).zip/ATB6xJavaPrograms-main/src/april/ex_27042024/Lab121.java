package src.april.ex_27042024;

public class Lab121 {
    public static void main(String[] args) {

        // While -> int -> condition -> body -> increment / decrement

        // Do While
        // int -> body -> condition -> incre / drement


        int a = 0;
        do{
            System.out.println(a);
            a--;
        }while (a > -5);

        // 0



    }
}
