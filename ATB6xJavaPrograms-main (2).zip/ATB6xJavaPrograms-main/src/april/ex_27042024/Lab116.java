package src.april.ex_27042024;

public class Lab116 {
    public static void main(String[] args) {
        for (int pramod = 10; pramod > 0 ; pramod--) {
            System.out.println(pramod);
        }

        for (int modi = 0; modi < 10 ; modi++) {

        }



    }
}
