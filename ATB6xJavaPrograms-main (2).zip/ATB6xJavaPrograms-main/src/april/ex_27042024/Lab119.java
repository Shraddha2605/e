package src.april.ex_27042024;

public class Lab119 {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 10) {
            System.out.println(i);
            i = i + 3;
        }

        int i1 = 10;
        while(i1>=1){
            System.out.println(i1);
            i1--;
        }

    }
}
