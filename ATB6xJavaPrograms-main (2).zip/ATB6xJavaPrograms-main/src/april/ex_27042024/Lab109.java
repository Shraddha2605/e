package src.april.ex_27042024;

public class Lab109 {
    public static void main(String[] args) {

        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
            // 1 to 10
            if (i == 5) {
                break;
            }
//            System.out.println(i);
            // i = 1 -> 1
            // i = 2 -> 2
            // i = 3 -> 3
            // i = 4 -> 4
            // i = 5 -> Out of loop
        }


    }
}
