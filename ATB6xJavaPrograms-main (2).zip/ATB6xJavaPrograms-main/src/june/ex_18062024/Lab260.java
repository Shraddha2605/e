package src.june.ex_18062024;

public class Lab260 {
    // Builder Pattern in Java
    // "this" always points to current/calling object. Returning the same to


    // Rest Assured - Can't use the Java Program IntellJ
    // Tool -
        // Allure Report
        // TestNG, Apache POI(DDT), AssertJ... so many lib, Cucmber BDD

        // Maintain Lib,Life Cycle - Install lib, updation, clean older, creating jars, running project
    // TestNG ?  0 Build Automation Tool - Java






}
