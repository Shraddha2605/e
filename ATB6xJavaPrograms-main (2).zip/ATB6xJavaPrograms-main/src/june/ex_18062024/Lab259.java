package src.june.ex_18062024;

public class Lab259 {
    public static void main(String[] args) {
        // Rest Assured
        //  Java Library -> Who will help you to make the HTTP Methods
        // GET, POST, PATCH, PUT, DELETE, HEAD....

        // Built functions - Direct functions
        // get(), put()

        // Assertions - Hamcrest - lib which can help you to validate the response
        // Body, status code, time and headers...

        // How to use it?
        // Just add to your project
        // Use it.


        // Rest Assured -> C#, .NET, Java , Python(More Power) - Request




    }
}
