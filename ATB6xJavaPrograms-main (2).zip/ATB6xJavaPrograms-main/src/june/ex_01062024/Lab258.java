package src.june.ex_01062024;

public class Lab258 {
    public static void main(String[] args) {
        System.out.println("Test");
    }
}
