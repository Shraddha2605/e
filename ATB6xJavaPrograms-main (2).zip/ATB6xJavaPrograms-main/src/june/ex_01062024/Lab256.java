package src.june.ex_01062024;

import java.util.ArrayList;
import java.util.List;

public class Lab256 {
    public static void main(String[] args) {
        // Generics
        // Generics is a feature in Java that was introduced in Java 5.0.
        // It allows you to abstract over types.

        List mylist = new ArrayList();
        mylist.add("Pramod");
        mylist.add(123);
        mylist.add(true);
//

    }
}
